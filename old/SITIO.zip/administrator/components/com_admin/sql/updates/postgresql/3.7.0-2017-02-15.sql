-- Normalize redirect_links table default values.
ALTER TABLE "#__redirect_links" ALTER COLUMN "comment" SET DEFAULT '';
