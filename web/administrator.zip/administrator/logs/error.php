#
#<?php die('Forbidden.'); ?>
#Date: 2020-08-17 20:56:17 UTC
#Software: Joomla Platform 13.1.0 Stable [ Curiosity ] 24-Apr-2013 00:00 GMT

#Fields: datetime	priority clientip	category	message
2020-08-17T20:56:17+00:00	INFO 190.47.2.40	joomlafailure	No se permiten contraseñas vacías
2020-08-17T20:56:29+00:00	INFO 190.47.2.40	joomlafailure	No se permiten contraseñas vacías
2020-08-17T21:05:34+00:00	INFO 190.47.2.40	joomlafailure	El usuario y contraseña no coinciden o usted aún no tiene una cuenta.
2020-08-17T21:09:39+00:00	INFO 190.47.2.40	joomlafailure	El usuario y contraseña no coinciden o usted aún no tiene una cuenta.
2020-08-18T05:39:36+00:00	INFO 190.47.2.40	joomlacanceled	
